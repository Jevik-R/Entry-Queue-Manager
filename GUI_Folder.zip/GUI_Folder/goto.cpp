// #include "goto.h"
// #include "ui_goto.h"

// GOTO::GOTO(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::GOTO)
// {
//     ui->setupUi(this);
//     updateNumber(24 , 53);
// }

// GOTO::~GOTO()
// {
//     delete ui;
// }
// // void GOTO::on_pushButton_clicked()
// // {
// //      // Done button
// // }

// void GOTO::updateNumber(int gateNoValue, int waitTimeValue)
// {
//     QString switchToText = QString::number(gateNoValue);
//     QString waitTimeText = QString::number(waitTimeValue);

//     // Set the text of the QLabel widgets
//     ui->GateNoNC_2->setText(switchToText);
//     ui->WaitTimeNC_2->setText(waitTimeText);
// }




// void GOTO::on_pushButton_2_clicked()
// {
//         hide() ;
// }

