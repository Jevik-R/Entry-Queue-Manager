// #include "family.h"
// #include "ui_family.h"
// #include "goto.h"
// #include "no_of_ppl.h"
// FAMILY::FAMILY(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::FAMILY)
// {
//     ui->setupUi(this);
// }

// FAMILY::~FAMILY()
// {
//     delete ui;
// }

// void FAMILY::on_Yes_clicked()
// {
//     // GOTO gate_fam;
//     // gate_fam.setModal(true);
//     // gate_fam.exec();
//     // hide();
//     NO_OF_PPL no_ppl;
//     no_ppl.setModal(true);
//     no_ppl.exec();

// }


// void FAMILY::on_No_clicked()
// {
//     GOTO gate_single;
//     gate_single.setModal(true);
//     gate_single.exec();
//     hide();
// }

