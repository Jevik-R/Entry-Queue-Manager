// #include "switch_to_gate.h"
// #include "ui_switch_to_gate.h"

// SWITCH_TO_GATE::SWITCH_TO_GATE(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::SWITCH_TO_GATE)
// {
//     ui->setupUi(this);
// }

// SWITCH_TO_GATE::~SWITCH_TO_GATE()
// {
//     delete ui;
// }

// void SWITCH_TO_GATE::on_pushButton_clicked()
// {
//     hide();
// }

