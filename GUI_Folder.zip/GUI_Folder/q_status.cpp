// #include "q_status.h"
// #include "ui_q_status.h"

// Q_STATUS::Q_STATUS(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::Q_STATUS)
// {
//     ui->setupUi(this);
//     ui->textEdit->setReadOnly(true);
//     onSentenceReceived("Hello! How ya doin'?");
// }

// Q_STATUS::~Q_STATUS()
// {
//     delete ui;
// }

// void Q_STATUS::appendSentence(const QString& sentence) {
//     ui->textEdit->append(sentence) ;
// }

// void Q_STATUS::onSentenceReceived(const QString& sentence){
//     appendSentence(sentence) ;
// }

