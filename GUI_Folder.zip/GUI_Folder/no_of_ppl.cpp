// #include "no_of_ppl.h"
// #include "ui_no_of_ppl.h"
// #include "goto.h"

// NO_OF_PPL::NO_OF_PPL(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::NO_OF_PPL)
// {
//     ui->setupUi(this);

// }

// NO_OF_PPL::~NO_OF_PPL()
// {
//     delete ui;
// }
// void NO_OF_PPL::on_Done_clicked()
// {
//     int MValue = ui->NoPeople->text().toInt();
//     GOTO gate ;
//     gate.setModal(true) ;
//     gate.exec() ;
//     hide() ;
// }
