// #include "vip.h"
// #include "ui_vip.h"
// #include"newcomeryn.h"

// VIP::VIP(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::VIP)
// {
//     ui->setupUi(this);
// }

// VIP::~VIP()
// {
//     delete ui;
// }

// void VIP::on_radioButton_clicked()
// {
//     NEWCOMERYN np_yn;
//         np_yn.setModal(true);
//         np_yn.exec();
//         hide();
// }


// void VIP::on_radioButton_2_clicked()
// {
//     NEWCOMERYN np_yn;
//             np_yn.setModal(true);
//             np_yn.exec();
//             hide();
// }

