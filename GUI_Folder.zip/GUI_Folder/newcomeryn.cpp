// #include "newcomeryn.h"
// #include "ui_newcomeryn.h"
// #include "family.h"
// #include "switch_info.h"
// NEWCOMERYN::NEWCOMERYN(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::NEWCOMERYN)
// {
//     ui->setupUi(this);
// }

// NEWCOMERYN::~NEWCOMERYN()
// {
//     delete ui;
// }

// void NEWCOMERYN::on_Yes_clicked()
// {
//     FAMILY fam_yn;
//     fam_yn.setModal(true);
//     fam_yn.exec();
//     hide();
// }


// void NEWCOMERYN::on_No_clicked()
// {
//     SWITCH_INFO switch_ppl;
//     switch_ppl.setModal(true);
//     switch_ppl.exec();
//     hide();

// }

