// #include "input_window.h"
// #include "ui_input_window.h"
// #include <QMessageBox>

// INPUT_WINDOW::INPUT_WINDOW(QWidget *parent)
//     : QDialog(parent)
//     , ui(new Ui::INPUT_WINDOW)
// {
//     ui->setupUi(this);
// }

// INPUT_WINDOW::~INPUT_WINDOW()
// {
//     delete ui;
// }

// void INPUT_WINDOW::on_pushButton_Done_clicked()
// {
//     hide();
//     QMessageBox::information(this, "Input Window", "Data Recorded Successfully");
//     hide();
// }

